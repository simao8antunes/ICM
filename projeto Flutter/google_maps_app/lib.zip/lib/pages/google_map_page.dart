import 'dart:async';
import 'dart:convert';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:location/location.dart';

class GoogleMapPage extends StatefulWidget {
  const GoogleMapPage({Key? key}) : super(key: key);

  @override
  State<GoogleMapPage> createState() => GoogleMapPageState();
}

class GoogleMapPageState extends State<GoogleMapPage> {
  final Completer<GoogleMapController> _controller = Completer();
  List<LatLng> polylineCoordinates = [];
  LocationData? currentPosition;

  BitmapDescriptor sourceIcon = BitmapDescriptor.defaultMarker;
  BitmapDescriptor poiIcon = BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue);

  @override
  void initState() {
    super.initState();
    loadCustomMarkerIcon();
    getCurrentLocationAndDrawPolyline();
  }

  Future<void> getCurrentLocation() async {
    Location location = Location();
    currentPosition = await location.getLocation();

    location.onLocationChanged.listen((newLoc) {
      currentPosition = newLoc;
      setState(() {});
      updateCameraPosition(newLoc.latitude!, newLoc.longitude!);
    });
  }

  // Method to handle selecting a point of interest and generating polyline
  Future<void> selectPointOfInterest(LatLng pointOfInterest) async {
    // Clear existing polyline coordinates
    setState(() {
      polylineCoordinates.clear();
    });

    // Get polyline points between current location and selected point of interest
    PolylinePoints polylinePoints = PolylinePoints();
    PolylineResult result = await polylinePoints.getRouteBetweenCoordinates(
      "AIzaSyCLQtvRikSwF0GP5j_Pl2kbVOeCf7syky0",
      PointLatLng(currentPosition!.latitude!, currentPosition!.longitude!),
      PointLatLng(pointOfInterest.latitude, pointOfInterest.longitude),
      travelMode: TravelMode.walking,
    );

    // If polyline points are available, update polylineCoordinates list
    if (result.points.isNotEmpty) {
      setState(() {
        polylineCoordinates = result.points
            .map((point) => LatLng(point.latitude, point.longitude))
            .toList();
      });
    }
  }

  Future<void> getPolyPoints() async {
    if (currentPosition == null) return;

    PolylinePoints polylinePoints = PolylinePoints();
    PolylineResult result = await polylinePoints.getRouteBetweenCoordinates(
      "AIzaSyCLQtvRikSwF0GP5j_Pl2kbVOeCf7syky0",
      PointLatLng(currentPosition!.latitude!, currentPosition!.longitude!),
      PointLatLng(41.1559, -8.6282),
    );

    if (result.points.isNotEmpty) {
      polylineCoordinates = result.points
          .map((point) => LatLng(point.latitude, point.longitude))
          .toList();
    }
  }

  void loadCustomMarkerIcon() async {
    final Uint8List markerIcon =
        await getBytesFromAsset('lib/Icon-192.png', 100);
    sourceIcon = BitmapDescriptor.fromBytes(markerIcon);
  }

  Future<Uint8List> getBytesFromAsset(String path, int width) async {
    ByteData data = await rootBundle.load(path);
    ui.Codec codec = await ui.instantiateImageCodec(data.buffer.asUint8List(),
        targetWidth: width);
    ui.FrameInfo fi = await codec.getNextFrame();
    return (await fi.image.toByteData(format: ui.ImageByteFormat.png))!
        .buffer
        .asUint8List();
  }

  Future<void> getCurrentLocationAndDrawPolyline() async {
    await getCurrentLocation();
    await getPolyPoints();
    await searchNearbyPlaces(); // Add this line to call searchNearbyPlaces
    setState(() {}); // Trigger redraw after obtaining location and polyline points
  }

  void updateCameraPosition(double latitude, double longitude) async {
    final GoogleMapController controller = await _controller.future;
    controller.animateCamera(CameraUpdate.newCameraPosition(
      CameraPosition(
        target: LatLng(latitude, longitude),
        zoom: 18,
      ),
    ));
  }

  Future<void> searchNearbyPlaces() async {
    if (currentPosition == null) return;

    final apiKey = 'AIzaSyCLQtvRikSwF0GP5j_Pl2kbVOeCf7syky0';
    final radius = 1000; // in meters
    final url =
        'https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${currentPosition!.latitude},${currentPosition!.longitude}&radius=$radius&key=$apiKey';

    final response = await http.get(Uri.parse(url));
    final data = json.decode(response.body);
    final results = data['results'];

    // Process the results and display on the map
    if (results != null && results.isNotEmpty) {
      for (final result in results) {
        final location = result['geometry']['location'];
        final lat = location['lat'];
        final lng = location['lng'];
        final name = result['name'];

        setState(() {
          nearbyPlacesMarkers.add(
            Marker(
              markerId: MarkerId(name),
              icon: poiIcon,
              position: LatLng(lat, lng),
              infoWindow: InfoWindow(title: name),
            ),
          );
        });
      }
    }
  }

  Set<Marker> nearbyPlacesMarkers = {}; // Define a set to hold nearby place markers

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "TITLE",
          style: TextStyle(color: Colors.black, fontSize: 16),
        ),
      ),
      body: currentPosition == null
          ? const Center(child: Text("Loading"))
          : GoogleMap(
              initialCameraPosition: CameraPosition(
                target: LatLng(currentPosition!.latitude!,
                    currentPosition!.longitude!),
                zoom: 18,
              ),
              polylines: {
                Polyline(
                  polylineId: PolylineId("route"),
                  points: polylineCoordinates,
                  width: 6,
                  color: Colors.blue,
                ),
              },
              markers: {
                ...nearbyPlacesMarkers,
                Marker(
                  markerId: const MarkerId("currentLocation"),
                  icon: sourceIcon, // Use custom marker icon
                  position: LatLng(currentPosition!.latitude!,
                      currentPosition!.longitude!),
                ),
              },
              onTap: (LatLng point) {
                // Handle tap on the map
                selectPointOfInterest(point);
              },
              onMapCreated: (mapController) {
                _controller.complete(mapController);
              }),
    );
  }
}
